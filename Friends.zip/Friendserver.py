from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
app = Flask(__name__)
mysql = MySQLConnector(app,'FriendAssign')
app.secret_key = 'Shhh KeepQuiet'

@app.route('/')
def Main():
	query = "SELECT * FROM friends" # define your query
	friendsResult = mysql.query_db(query) # run query with query_db()
	return render_template('friends.html', friends=friendsResult)

@app.route('/check', methods=["POST"])
def Check():
	NAME = re.compile(r'.*\d+.*')
	if len(request.form['first_name']) <1 or len(request.form['last_name']) <1 or len(request.form['occupation']) <1:
		flash("Please Fill out ALL of the Form")
		return redirect('/')
	else:
		return redirect('/friends')

@app.route('/friends', methods=["POST"])
def Display():
	query = "INSERT INTO friends (first_name, last_name, occupation, created_at, updated_at) VALUES (:first_name, :last_name, :occupation, NOW(), NOW())"
	data = {'first_name': request.form['first_name'], 'last_name':  request.form['last_name'],'occupation': request.form['occupation']}
	mysql.query_db(query, data)
	return redirect('/')

@app.route('/modify', methods=['POST'])
def Modify():

	return render_template("Modify.html")


@app.route('/update', methods=['POST'])
def Update():
	# query = "UPDATE friends SET first_name = '{}'".format(request.form['first_name'])
	# query = "UPDATE friends SET first_name = '{}' WHERE id = 1".format(request.form['first_name'])
	query = "UPDATE friends SET first_name = '{}', last_name = '{}', occupation = '{}' WHERE id = {}".format(request.form['first_name'], request.form['last_name'], request.form['occupation'], request.form['id'])
	mysql.query_db(query)
	return redirect('/')

@app.route('/delete', methods=['POST'])
def Delete():
	query = "DELETE FROM friends WHERE id = {}".format(request.form['id'])
	mysql.query_db(query)
	return redirect('/')

app.run(debug=True)